# 코드 6-7 count가 2일 때 멈추는 코드
count = 0
while count < 3:
    count = count + 1
    if count == 2:
        break
    print(count)
