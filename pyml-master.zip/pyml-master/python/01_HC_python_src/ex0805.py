﻿# 코드 8-5 함수를 사용해 판결을 내리는 코드
def judge_cards(name):
    print(name, '1 유죄!')
    print(name, '2 유죄!')
    print(name, '3 유죄!')

judge_cards('하트')
judge_cards('클로버')
judge_cards('스페이드')
