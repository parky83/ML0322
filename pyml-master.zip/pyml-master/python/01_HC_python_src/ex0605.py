# 코드 6-5 영국의 수도를 묻는 코드
answer = ''
while answer != '런던':
    answer = input('영국의 수도는 어디일까요? ')
print('정답입니다.')
