﻿# 코드 8-4 함수를 사용해 두 개의 숫자를 더하고 곱하는 코드
def add_mul(num1, num2):
    return num1 + num2, num1 * num2

print(add_mul(2, 3))
