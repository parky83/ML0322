# 코드 1-2 print()를 잘못 사용한 코드
Print('Hello World!')
