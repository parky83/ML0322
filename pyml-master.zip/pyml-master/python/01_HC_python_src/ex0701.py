# 코드 7-1 튜플을 만드는 코드
my_tuple1 = ()
print(my_tuple1)
my_tuple2 = (1, -2, 3.14)
print(my_tuple2)
my_tuple3 = '앨리스', 10, 1.0, 1.2
print(my_tuple3)
