# 코드 3-6 리스트에서 값을 제거하는 코드
clovers = ['클로버1', '클로버2', '클로버3']
print(clovers[1])
del clovers[1]
print(clovers)
print(clovers[1])
