# 코드 5-11 점수에 따라 합격여부를 출력하는 코드
score = 60
if score > 80:
    print('합격입니다.')
else:
    print('불합격입니다.')
