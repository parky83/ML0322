# 코드 5-16 or의 결과를 확인하는 코드
print(True or True)
print(True or False)
print(False or True)
print(False or False)
