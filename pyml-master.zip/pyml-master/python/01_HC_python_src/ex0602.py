# 코드 6-2 while을 사용해 거북이에게 인사하는 코드
num = 0
while num < 3:
    print('안녕 거북이', num)
    num = num + 1
