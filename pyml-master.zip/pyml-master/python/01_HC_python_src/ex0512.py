# 코드 5-12 점수에 따라 학점을 출력하는 코드
score = 75
if 80 < score <= 100:
    print('학점은 A입니다.')
elif 60 < score <= 80:
    print('학점은 B입니다.')
elif 40 < score <= 60:
    print('학점은 C입니다.')
else:
    print('학점은 F입니다.')
