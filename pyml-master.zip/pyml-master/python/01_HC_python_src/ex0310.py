# 코드 3-10 리스트의 문자열을 정렬하는 코드
animals = ['체셔고양이', '오리', '도도새']
animals.sort()
print(animals)
