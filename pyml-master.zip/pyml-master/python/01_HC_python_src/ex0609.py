# 코드 6-9 끝없이 반복해서 출력하는 코드
while True:
    print('Ctrl+C를 누르세요.')
