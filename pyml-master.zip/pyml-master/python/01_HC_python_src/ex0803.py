﻿# 코드 8-3 함수를 사용해 두 개의 숫자를 더하는 코드
def add(num1, num2):
    return num1 + num2
 
print(add(2, 3))
