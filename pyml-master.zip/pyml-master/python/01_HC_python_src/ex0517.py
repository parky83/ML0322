# 코드 5-17 not의 결과를 확인하는 코드
print(not True)
print(not False)
