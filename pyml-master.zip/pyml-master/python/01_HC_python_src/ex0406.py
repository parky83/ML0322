# 코드 4-6 문자열의 문자를 하나씩 출력하는 코드
for letter in '체셔고양이':
    print(letter)
