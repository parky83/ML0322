# 코드 3-7 사탕을 추가하고 제거하는 코드
candies = ['딸기맛', '레몬맛', '수박맛', '박하맛', '우유맛']
print(candies)
candies.append('콜라맛')
candies.append('포도맛')
print(candies)
del candies[3]
print(candies)
