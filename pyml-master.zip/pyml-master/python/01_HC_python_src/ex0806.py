# 코드 8-6 하나의 값을 임의로 선택하는 코드
import random
animals = ['체셔고양이', '오리', '도도새']
print(random.choice(animals))
