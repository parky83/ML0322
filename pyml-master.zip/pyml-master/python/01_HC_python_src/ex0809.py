# 코드 8-9 임의로 카드 하나를 뽑는 코드
import random
cards = ['하트', '클로버', '스페이드']
chosen_card = random.choice(cards)
print(chosen_card, '유죄!')
