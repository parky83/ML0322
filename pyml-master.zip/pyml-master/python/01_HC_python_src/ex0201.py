# 코드 2-1 다양한 숫자를 출력하는 코드
print(1)
print(-2)
print(3.14)
