# 코드 6-8 count가 2일 때 멈추는 코드
for count in range(1, 3):
    if count == 2:
        break
    print(count)
