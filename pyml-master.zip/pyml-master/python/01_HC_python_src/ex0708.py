# 코드 7-8 딕셔너리에 키-값을 추가하는 코드
clover = {'나이': 27, '직업': '병사'}
print(clover)
clover['번호'] = 9
print(clover)
