﻿# 코드 4-2 거북이 5,000마리에게 인사하는 코드
for num in range(5000):
    print('안녕 거북이', num)
