# 코드 7-5 패킹과 언패킹을 하는 코드
clovers = '클로버1', '클로버2', '클로버3'
print(clovers)
alice_blue = (240, 248, 255)
r, g, b = alice_blue
print('R:', r, 'G:', g, 'B:', b)
