﻿# 코드 8-2 함수를 사용해 문자열을 출력하는 코드
def my_func():
    print('토끼야 안녕!')
 
my_func()
