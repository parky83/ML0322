# 코드 4-9 0부터 2까지 차례로 출력하는 코드
for num in range(3):
    print(num)
