# 코드 3-4 리스트에 값을 추가하는 코드
clovers = []
clovers.append('클로버1')
print(clovers)
clovers.append('하트2')
print(clovers)
clovers.append('클로버3')
print(clovers)
