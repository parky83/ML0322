# 코드 2-5 문자열을 출력하는 코드
print('Hello World!')
print('3.14')
print('토끼야 안녕!')
print("토끼야 안녕!")
