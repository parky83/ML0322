# 코드 4-11 모든 ‘하얀장미’를 ‘빨간장미’로 바꾸는 코드
roses = ['하얀장미', '하얀장미', '하얀장미']
for i in range(3):
    roses[i] = '빨간장미'
print(roses)
