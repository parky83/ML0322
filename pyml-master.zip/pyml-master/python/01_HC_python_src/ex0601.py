# 코드 6-1 for를 사용해 거북이에게 인사하는 코드
for num in range(3):
    print('안녕 거북이', num)
