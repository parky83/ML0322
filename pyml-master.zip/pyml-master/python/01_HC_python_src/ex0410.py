# 코드 4-10 구구단 2단을 출력하는 코드
for y in range(1, 10):
    print(2, 'x', y, '=', 2 * y)
