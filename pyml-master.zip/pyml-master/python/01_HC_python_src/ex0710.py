# 코드 7-10 딕셔너리에서 키-값을 제거하는 코드
clover = {'나이': 27, '직업': '병사', '번호': 6}
print(clover)
del clover['나이']
print(clover)
