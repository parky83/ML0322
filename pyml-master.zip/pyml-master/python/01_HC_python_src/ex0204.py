# 코드 2-4 다양한 연산을 하는 코드
print(3 + 7)
print(6 * 3)
print(4 ** 2)
print(9 % 5)
