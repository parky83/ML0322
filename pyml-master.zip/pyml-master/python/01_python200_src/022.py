a = True
b = False
print(a == 1)       # True가 출력됨
print(b != 0)        # False가 출력됨
