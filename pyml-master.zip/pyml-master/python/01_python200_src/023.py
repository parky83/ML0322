x = 1; y = 2
str1 = 'abc'; str2 = 'python'
print(x == y)  # False가 출력됨
print(x != y)   # True가 출력됨
print(str1 == str2)   # False가 출력됨
print(str2 == 'python')   # True가 출력됨
print(str1 < str2)        # True가 출력됨
