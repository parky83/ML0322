solarsys = ['태양', '수성', '금성', '지구', '화성', '목성', '토성', '천왕성', '해왕성']
del solarsys[0]
print(solarsys)
del solarsys[-2]
print(solarsys)
