
scope = [1, 2, 3]

for x in scope:
    print(x)
    break
else:
    print('Perfect')
