strdata1 = 'I love '; strdata2 = 'Python'; strdata3 = 'you'
listdata1 = [1, 2, 3]; listdata2 = [4, 5, 6]
print(strdata1 + strdata2)     # ‘I love Python’이 출력됨
print(strdata1 + strdata3)     # ‘I love you’가 출력됨
print(listdata1 + listdata2)    # [1, 2, 3, 4, 5, 6]이 출력됨
