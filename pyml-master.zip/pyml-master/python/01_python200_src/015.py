int_data = 10
bin_data = 0b10 # 2진수  binary
oct_data = 0o10 # 8진수  octal
hex_data = 0x10 # 16진수  hexadecimal 
long_data = 1234567890123456789
print(int_data)
print(bin_data)
print(oct_data)
print(hex_data)
print(long_data)
print(type(long_data))
