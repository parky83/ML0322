﻿txt1 = 'A tale that was not right'
txt2 = '이 또한 지나가리라.'
print(txt1[3:7])      # ‘ale ’이 출력됨
print(txt1[:6])       # ‘A tale’ 이 출력됨
print(txt2[-4:])      # ‘가리라.’가 출력됨
