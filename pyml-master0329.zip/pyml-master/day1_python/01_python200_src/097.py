b_txt = b'A lot of things occur each day.'
u_txt = b_txt.decode()
print(u_txt)
