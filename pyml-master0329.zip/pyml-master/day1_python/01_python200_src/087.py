txt = 'A lot of Things occur each day.'
ret1 = txt.upper()
ret2 = txt.lower()
print(ret1)       # ‘A LOT OF THINGS OCCUR EACH DAY.’가 출력됨
print(ret2)       # ‘a lot of things occur each day.’가 출력됨
