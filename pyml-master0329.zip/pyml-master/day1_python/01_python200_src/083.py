msg = input('임의의 문장을 입력하세요: ')
msglen = len(msg)
#msglen = len(msg.encode())
print('당신이 입력한 문장의 길이는 <%d> 입니다.' %msglen)
