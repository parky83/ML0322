listdata = [1, 2, 'a', 'b', 'c', [4, 5, 6]]
val1 = listdata[1]
val2 = listdata[3]
val3 = listdata[5][1]
print(val1)   # 2가 출력됨
print(val2)   # ‘b’가 출력됨
print(val3)   # 5가 출력됨
