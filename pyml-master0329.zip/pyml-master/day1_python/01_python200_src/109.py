listdata = []
for i in range(3):
   txt = input('리스트에 추가할 값을 입력하세요[%d/3]: ' %(i+1))
   listdata.append(txt)
   print(listdata)
