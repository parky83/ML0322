msg = input('임의의 문장을 입력하세요: ')
if 'a' in msg:
   print('당신이 입력한 문장에는 a가 있습니다.')
else:
   print('당신이 입력한 문장에는 a가 없습니다.')
