txt = 'A lot of things occur each day, every day.'
word_count1 = txt.count('o')
word_count2 = txt.count('day')
word_count3 = txt.count(' ')
print(word_count1)  # 3이 출력됨
print(word_count2)  # 2가 출력됨
print(word_count3)  # 8이 출력됨
