a = 107    # 16진수로 0x6b
b = a & 0x0f
print(hex(b))     # 11이 출력됨. 11은 16진수로 b임
