# 코드 2-10 변수에 저장한 값을 변경하는 코드
count = 0
print(count)
count = 1
print(count)
count = count + 1
print(count)
