# 코드 6-4 이름을 입력 받는 코드
name = input('이름이 뭔가요? ')
print(name, '안녕!')
