# 코드 3-8 리스트에서 여러 개의 값을 가져오는 코드
week = ['월', '화', '수', '목', '금', '토', '일']
print(week)
print(week[2:5])
print(week)
