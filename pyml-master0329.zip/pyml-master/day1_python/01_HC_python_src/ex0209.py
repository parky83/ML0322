# 코드 2-9 변수에 저장한 문자열을 출력하는 코드
rainbow = '빨주노초파남보'
print(rainbow)
