# 코드 1-1 ‘Hello World!’를 출력하는 코드
print('Hello World!')
