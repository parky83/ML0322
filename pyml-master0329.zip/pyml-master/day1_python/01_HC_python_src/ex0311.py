# 코드 3-11 리스트에서 특정 값의 개수를 세는 코드
cards = ['하트', '클로버', '하트', '다이아']
print(cards.count('하트'))
print(cards.count('클로버'))
