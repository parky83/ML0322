# 코드 8-8 지정한 범위에서 임의의 정수를 선택하는 코드
import random
print(random.randint(5, 10))
