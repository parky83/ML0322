# 코드 7-7 딕셔너리를 만드는 코드
my_dict1 = {}
print(my_dict1)
my_dict2 = {0: 1, 1: -2, 2: 3.14}
print(my_dict2)
my_dict3 = {'이름': '앨리스', '나이': 10, '시력': [1.0, 1.2]}
print(my_dict3)
