# 코드 7-2 값이 한 개인 튜플을 만드는 코드
my_int = (1)
print(type(my_int))
my_tuple = (1,)
print(type(my_tuple))
