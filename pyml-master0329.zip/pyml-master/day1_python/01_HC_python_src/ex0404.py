# 코드 4-4 리스트의 문자열을 차례대로 출력하는 코드
characters = ['앨리스', '도도새', '3월토끼']
for character in characters:
    print(character)
