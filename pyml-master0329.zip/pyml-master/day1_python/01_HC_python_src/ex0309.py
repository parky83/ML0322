# 코드 3-9 리스트에서 값을 가져오는 코드
candies = ['딸기맛', '레몬맛', '수박맛', '우유맛', '콜라맛', '포도맛']
cat_candy = candies[0]
print('체셔고양이에게는', cat_candy, '사탕을 줘요.')
duck_candy = candies[1]
print('오리에게는', duck_candy, '사탕을 줘요.')
dodo_candies = candies[3:6]
print('도도새에게는', dodo_candies, '사탕을 줘요.')
