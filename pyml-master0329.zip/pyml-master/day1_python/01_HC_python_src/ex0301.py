# 코드 3-1 여러 개의 변수에 사탕을 저장하는 코드
candy0 = '딸기맛'
print(candy0)
candy1 = '레몬맛'
print(candy1)
candy2 = '수박맛'
print(candy2)
candy3 = '박하맛'
print(candy3)
candy4 = '우유맛'
print(candy4)
