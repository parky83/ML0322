# 코드 4-5 모든 신하에게 퇴장 명령을 내리는 코드
players = ['공작부인', '흰 토끼', '하트잭', '모자장수']
for player in players:
    print(player, '퇴장!')
