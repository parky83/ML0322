# 코드 5-14 여러 조건을 판단하는 코드
games = 12
points = 25
if games >= 10 and points >= 20:
    print('MVP로 선정되었습니다.')
