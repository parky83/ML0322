# 코드 2-11 변수를 사용해 음료의 총 금액을 계산하는 코드
coffee = 4100
juice = 4600
tea = 3900
print(coffee * 3 + juice * 2 + tea * 1)
print(coffee * 4 + juice * 3 + tea * 3)
print(coffee * 1 + juice * 1 + tea * 2)
