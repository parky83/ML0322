# 코드 3-3 리스트를 만드는 코드
my_list1 = []
print(my_list1)
my_list2 = [1, -2, 3.14]
print(my_list2)
my_list3 = ['앨리스', 10, [1.0, 1.2]]
print(my_list3)
