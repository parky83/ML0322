# 코드 6-3 경주로를 다섯 바퀴만 돌게 하는 코드
count = 0
while count < 5:
    count = count + 1
    print(count, '번째 바퀴입니다.')
print('경주 끝!')
