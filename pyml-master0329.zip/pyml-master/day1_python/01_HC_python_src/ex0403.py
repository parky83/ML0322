# 코드 4-3 리스트의 숫자를 차례대로 출력하는 코드
for num in [0, 1, 2]:
    print(num)
