# 코드 2-2 더하기, 빼기, 곱하기, 나누기를 하는 코드
print(1 + 2)
print(3 - 2)
print(2 * 4)
print(6 / 3)
