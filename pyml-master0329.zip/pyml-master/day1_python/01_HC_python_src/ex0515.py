# 코드 5-15 and의 결과를 확인하는 코드
print(True and True)
print(True and False)
print(False and True)
print(False and False)
