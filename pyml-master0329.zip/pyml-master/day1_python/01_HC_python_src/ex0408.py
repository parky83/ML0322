# 코드 4-8 리스트의 숫자를 차례대로 출력하는 코드
nums = [0, 1, 2]
for num in nums:
    print(num)
    print(nums)
