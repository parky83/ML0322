# 코드 3-5 리스트의 값에 접근하는 코드
clovers = ['클로버1', '하트2', '클로버3']
print(clovers[1])
clovers[1] = '클로버2'
print(clovers[1])
print(clovers[3])
