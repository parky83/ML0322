# 코드 5-1 True와 False를 출력하는 코드
print(True)
print(False)
